﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PEstoque01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int [,] estoque = new int[2, 4];
            string entrada = "";

            int acum_total= 0;
            for (int i= 0; i< 2; i++)
            {
                int acumulador = 0;
                for (int j= 0; j < 4; j++)
                {
                    entrada = Interaction.InputBox($"Total de entrada do produto {i + 1} Semana {j + 1}: ", "Produtos");
                    if(entrada == "")
                    {
                        MessageBox.Show("Cancelado");
                        lstBx1.Items.Clear();
                        return;
                    }
                    if(!int.TryParse(entrada, out estoque[i, j]))
                    {
                        MessageBox.Show("Dado invalido");
                        j--;
                        continue;
                    }

                    if (estoque[i,j] < 0)
                    {
                        MessageBox.Show("Valor precisa ser maior ou igual a 0");
                        j--;
                        continue;
                    }

                    acumulador += estoque[i, j];
                    lstBx1.Items.Add($"Total de entrada do produto {i + 1} Semana {j + 1}: - "+ estoque[i,j]);
                }
                lstBx1.Items.Add($">> Total de entrada do produto {i + 1}: - " + acumulador);
                lstBx1.Items.Add("----------------------------------------------------------");
                acum_total += acumulador;

            }
            lstBx1.Items.Add($">> Total Geral Entradas: " + acum_total);


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstBx1.Items.Clear();
        }
    }
}
