﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNumero2, "");
                numero2 = Convert.ToDouble(txtNumero2.Text);
            }
            catch (Exception)
            {
                errorProvider2.SetError(txtNumero2, "Número 2 inválido");
            }
        }

       

        private void btnLimpar_Validated(object sender, EventArgs e)
        {
            txtNumero1.Focus();
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

      
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Focus();
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?",
               "Saída", MessageBoxButtons.YesNo,
               MessageBoxIcon.Question) ==
               DialogResult.Yes) 
            {
                Close();
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1) ||
                !Double.TryParse(txtNumero2.Text, out numero2))
            {
                txtNumero1.Focus();
            }
            else
            {
                resultado = numero1 + numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1) ||
                !Double.TryParse(txtNumero2.Text, out numero2))
            {
                txtNumero1.Focus();
            }
            else
            {
                resultado = numero1 - numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1) ||
               !Double.TryParse(txtNumero2.Text, out numero2))

            {
                txtNumero1.Focus();
            }
            else
            {
                if (numero2 == 0)
                {
                    errorProvider2.SetError(txtNumero2, "Número inválido");
                    txtNumero2.Focus();
                }
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1) ||
                !Double.TryParse(txtNumero2.Text, out numero2))
            {
                txtNumero1.Focus();
            }
            else
            {
                resultado = numero1 * numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                //MessageBox.Show("Número 1 inválido");
                errorProvider1.SetError(txtNumero1, "Número 1 inválido");
                //txtNumero1.Focus();
            }
            else
            {
                errorProvider1.SetError(txtNumero1, "");
            }

          
        }
    }
}
