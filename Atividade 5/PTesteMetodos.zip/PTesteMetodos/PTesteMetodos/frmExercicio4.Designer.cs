﻿
namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContaNumeros = new System.Windows.Forms.Button();
            this.btnEspacoEmBranco = new System.Windows.Forms.Button();
            this.btnContarLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(184, 21);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(304, 182);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnContaNumeros
            // 
            this.btnContaNumeros.Location = new System.Drawing.Point(115, 221);
            this.btnContaNumeros.Name = "btnContaNumeros";
            this.btnContaNumeros.Size = new System.Drawing.Size(95, 59);
            this.btnContaNumeros.TabIndex = 1;
            this.btnContaNumeros.Text = "Contar Números";
            this.btnContaNumeros.UseVisualStyleBackColor = true;
            this.btnContaNumeros.Click += new System.EventHandler(this.btnContaNumeros_Click);
            // 
            // btnEspacoEmBranco
            // 
            this.btnEspacoEmBranco.Location = new System.Drawing.Point(281, 221);
            this.btnEspacoEmBranco.Name = "btnEspacoEmBranco";
            this.btnEspacoEmBranco.Size = new System.Drawing.Size(86, 59);
            this.btnEspacoEmBranco.TabIndex = 2;
            this.btnEspacoEmBranco.Text = "Primeiro Espaço em Branco";
            this.btnEspacoEmBranco.UseVisualStyleBackColor = true;
            this.btnEspacoEmBranco.Click += new System.EventHandler(this.btnEspacoEmBranco_Click);
            // 
            // btnContarLetras
            // 
            this.btnContarLetras.Location = new System.Drawing.Point(455, 221);
            this.btnContarLetras.Name = "btnContarLetras";
            this.btnContarLetras.Size = new System.Drawing.Size(96, 59);
            this.btnContarLetras.TabIndex = 3;
            this.btnContarLetras.Text = "Contar Letras";
            this.btnContarLetras.UseVisualStyleBackColor = true;
            this.btnContarLetras.Click += new System.EventHandler(this.btnContarLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContarLetras);
            this.Controls.Add(this.btnEspacoEmBranco);
            this.Controls.Add(this.btnContaNumeros);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContaNumeros;
        private System.Windows.Forms.Button btnEspacoEmBranco;
        private System.Windows.Forms.Button btnContarLetras;
    }
}