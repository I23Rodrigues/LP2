﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_TextChanged(object sender, EventArgs e)
        {
            double Raio;
            if (!double.TryParse(txtRaio.Text, out Raio))
            {
                MessageBox.Show("Raio Invalido");
                txtRaio.Focus();
            }
            else if (Raio <= 0)
            {
                MessageBox.Show("Raio deve ser maior que zero");
                txtRaio.Focus();
            }
        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {
            double Altura;
            if (!double.TryParse(txtAltura.Text, out Altura))
            {
                MessageBox.Show("Altura Invalida");
                txtRaio.Focus();
            }
            else if (Altura <= 0)
            {
                MessageBox.Show("Altura deve ser maior que zero");
                txtRaio.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double Volume, Raio, Altura;
            if (!double.TryParse(txtRaio.Text, out Raio)|| !double.TryParse(txtAltura.Text, out Altura)|| Raio <= 0 || Altura <=0)
            {
                MessageBox.Show("Valores Invalidos");
                txtRaio.Focus();
            }
            else
            {
                Volume = Math.PI * Math.Pow(Raio, 2) * Altura;
                txtResultado.Text = Volume.ToString("N2");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = "";
            txtResultado.Text = "";
        }
    }
}
