﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            

            foreach (char x in rchtxtFrase.Text) 
            {
                if (x == ' ')
                    posicao += 1;
            }

            MessageBox.Show($"Quantidade de espaços em branco: {posicao}");
        }

        private void btnLetra_Click(object sender, EventArgs e)
        {
            int R = 0;
            int i = 0;
            do
            {
                if (Char.ToUpper(rchtxtFrase.Text[i]) == 'R')
                    R++;

                i++;
            }
            while (i < rchtxtFrase.Text.Length);

            MessageBox.Show($"Quantidade de letras 'R' na frase: {R}");
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            int qtdPares = 0;
            int i, y;

            for (i = 0, y = 1; y<rchtxtFrase.Text.Length; i++, y++)
            {
                if (rchtxtFrase.Text.ToLower()[i] == rchtxtFrase.Text.ToLower()[y])
                    qtdPares++;
            }
            MessageBox.Show($"Quantidade de pares de letras na frase: {qtdPares}");
        }
    }
}
