﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double a, b, c;

        private void txtB_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtB.Text, out b))
            {
                MessageBox.Show("Número inválido");
                txtB.Focus();
            }
        }

        private void txtC_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtC.Text, out c))
            {
                MessageBox.Show("Número inválido");
                txtC.Focus();
            }
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtA.Text, out a) ||
                !Double.TryParse(txtB.Text, out b) ||
                !Double.TryParse(txtC.Text, out c))
            {
                txtA.Focus();
                txtA.Text = a.ToString();
                txtB.Text = b.ToString();
                txtC.Text = c.ToString();

            }
            else if(a > Math.Abs(b - c) && a < Math.Abs(b + c) &&
                   b > Math.Abs(a - c) && b < Math.Abs(a + c) &&
                   c > Math.Abs(a - b) && c < (a + b))
            {
                if (a == b && b != c)
                {
                    MessageBox.Show("Triângulo Isóceles");
                }
                else if (a == b && b == c)
                {
                    MessageBox.Show("Triângulo Equilátero");
                } 
                else if (a!= b && b != c)
                {
                    MessageBox.Show("Triângulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Não é um triângulo");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Text = "";
            txtB.Text = "";
            txtC.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtA_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtA.Text, out a))
            {
                MessageBox.Show("Número inválido");
                txtA.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
